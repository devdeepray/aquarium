#include <simplecpp>

int main(){
  initCanvas("Trtest",0,0,800,800);
  Line l(100,100, 300,200);
  l.imprint();
  getClick();
  for(int i=0; i<5; i++){
    l.rotate(PI/10);
    l.imprint();
    wait(0.1);
  }
  getClick();
}


    
