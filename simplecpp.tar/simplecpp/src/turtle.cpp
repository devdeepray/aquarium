#include <simplecpp>

Turtle::Turtle(Composite* owner)
  : Polygon(owner)
{
  double pts_body[4][2] = {{0, 15}, {20, 0}, {0, -15}, {0,15}};
  setColor(COLOR("red"), false);
  setFill();
  penDown();
  init(pts_body, 4);
}
