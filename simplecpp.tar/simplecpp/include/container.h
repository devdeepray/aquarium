#ifndef _SPRITE_INCLUDED_
#define _SPRITE_INCLUDED_

#include <iostream>
#include <vector>

using namespace std;

class sprite{
public:
  vector<sprite *> parts;

};
#endif
